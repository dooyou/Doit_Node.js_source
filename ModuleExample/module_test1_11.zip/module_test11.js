const User = require('./user11').User;
const user = new User('mugmug', '강아지');

user.printUser();
