const User = require('./user10');
const user = new User('mugmug', '강아지');

user.printUser();
