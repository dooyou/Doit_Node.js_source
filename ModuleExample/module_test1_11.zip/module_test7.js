const printUser = require('./user7').printUser;
printUser();
