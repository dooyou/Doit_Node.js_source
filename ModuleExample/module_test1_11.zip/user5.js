module.exports = {
  getUser: () => {
    return {id: 'test01', name: '강아지'};
  },
  group : {id:'group01', name:'고양이'}
}

exports.gorup =  {id:'group02', name:'토끼'};
