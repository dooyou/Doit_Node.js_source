const animal = require('./user_animal');

console.log('사용자 정보 : ', animal.getAnimal().name, animal.group.name );
