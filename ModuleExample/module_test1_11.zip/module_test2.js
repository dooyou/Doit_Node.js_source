const user3 = require('./user3');
console.dir(user3);

function showUser() {
  return user3.getUser().name + ', '+ user3.group.name;
}

console.log(showUser());
