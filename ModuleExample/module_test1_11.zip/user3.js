const user3 = {
  getUser : function() {
    return {id:'test01', name:'강아지'};
  },
  group : {id:'group01', name:'고양이'}
}

module.exports = user3;
