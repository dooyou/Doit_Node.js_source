exports.printUser = () =>{
  console.log('user 이름은 강아지입니다.');
}
