const user = require('./user4');
console.dir(user);

function showUser() {
  return user().name + ', No Group ';
}

console.log(showUser());
