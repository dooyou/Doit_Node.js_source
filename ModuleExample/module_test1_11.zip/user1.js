//exports 객체 속성으로 함수 추가
exports.getUser = function() {
  return {id:'test01', name:'강아지'};
}

// exports 객체 속성으로 객체 추가
exports.group = {id:'group01', name:'고양이'};
