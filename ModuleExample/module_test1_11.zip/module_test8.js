const user = require('./user8');
user.printUser();
