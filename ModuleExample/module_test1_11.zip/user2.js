exports = {
  getUser : function() {
    return {id:'test01', name:'강아지'};
  },
  group : {id:'group01', name:'고양이'}
}
