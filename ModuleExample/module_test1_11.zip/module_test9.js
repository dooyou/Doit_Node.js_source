const user = require('./user9').user;
user.printUser();
