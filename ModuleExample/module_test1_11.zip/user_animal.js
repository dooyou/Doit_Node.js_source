exports.getAnimal = () => {
  return {id:'mugmug', name:'강아지'};
}

exports.group = {id:'yaung', name:'고양이'};
