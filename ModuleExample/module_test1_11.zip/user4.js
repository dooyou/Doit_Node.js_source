module.exports  = () => {
    return {id:'test01', name:'강아지'};
  };
